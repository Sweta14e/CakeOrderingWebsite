const express = require('express')
const api = require('./api')
const morgan = require('morgan') // logger
const cors = require('cors')
const multer = require('multer');


const app = express()




app.set('port', (process.env.PORT || 8081))

app.use(express.json())
app.use(express.urlencoded({ extended: false }))

app.use(cors())

app.use('/api', api)
app.use(express.static('static'))



app.use(morgan('dev'))



const ImageSchema = require('./image.model');

//Storage
const Storage = multer.diskStorage({
    destination: 'uploads',
    filename : (req, file, cb) =>{
        cb(null,file.originalname);
    },
});

const upload = multer({
    storage:Storage
}).single('testImage')



app.post('/upload',(req,res)=>{
    upload(req,res,(err)=>{
        if(err){
            console.log(err)
        }
        else{
            const newImage = new ImageSchema({
                name: req.body.name,
                price: req.body.price,
                description: req.body.description,
                image :{
                    data: req.file.filename,
                    contentType: 'image/jpg'
                }

            })
            newImage.save()
            .then(()=> res.send('successfully uploaded')).catch((err) => console.log(err));
        }
    })
})






app.use(function (req, res) {
const err = new Error('Not Found')
err.status = 404
res.json(err)
})

// MongoDB connection
const mongoose = require('mongoose');
// const imageModel = require('./models/image.model');
mongoose.connect('mongodb://localhost:27017/virtualstandups', { useNewUrlParser: true })

const db = mongoose.connection
db.on('error', console.error.bind(console, 'connection error:'))
db.once('open', function () {
console.log('Connected to MongoDB')

app.listen(app.get('port'), function () {
console.log('API Server Listening on port ' + app.get('port') + '!')
})
})