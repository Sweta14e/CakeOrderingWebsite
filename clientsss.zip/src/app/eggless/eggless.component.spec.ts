import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EgglessComponent } from './eggless.component';

describe('EgglessComponent', () => {
  let component: EgglessComponent;
  let fixture: ComponentFixture<EgglessComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EgglessComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EgglessComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
