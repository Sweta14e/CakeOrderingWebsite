import { Component, OnInit } from '@angular/core';
import { CartService } from '../cart.service';

@Component({
  selector: 'app-egless',
  templateUrl: './egless.component.html',
  styleUrls: ['./egless.component.css']
})
export class EglessComponent implements OnInit {

 


  imageSrc = [{image:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS8_dWmVC9iyKf8Iew8BOevy8_MqWyagkRFP97xVFh_hxK-u52-UBq-gv9vtclOLsqHZo8&usqp=CAU",name:"Vanila Flavour",price:599},
{image:"https://cdn.shopify.com/s/files/1/0521/3929/4884/products/eggless-chocolate-orange-mousse-cake1_400x400.jpg?v=1662007983",name:"Chocolate Flavour",price:499},
{image:"https://5.imimg.com/data5/SELLER/Default/2021/2/EW/AW/JZ/55560793/pineapple-cake-1kg-500x500.jpeg",name:"PineApple Flavour",price:599},
{image:"https://www.basilflorist.com/image/cache/catalog/Flowers/cakes/choco-butterscotch-cake1-700x700.jpg",name:"Butter Scotch Flavour",price:699},
{image:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ_7S0_sjm2-ryFNHrPeHnTssQyTRem3-cupL1BJ6BLrnFnpOuIoQJi6OrmvktdOlNzMsM&usqp=CAU",name:"Vanila Flavour",price:450},
{image:"https://cdn.shopify.com/s/files/1/0509/1704/8471/products/RedVelvetCake_grande.jpg?v=1612357784",name:"Red Velvet Flavour",price:699},
{image:"https://content.jdmagicbox.com/comp/vijayawada/x8/0866px866.x866.211026094808.m2x8/catalogue/-lgxd7f7626.jpg?clr=",name:"Chocolate Flavour",price:399},
{image:"https://assets.winni.in/c_limit,dpr_2,fl_progressive,q_80,w_220/73538_choco-strawberry-cake.jpeg",name:"Straberry Flavour",price:899},
{image:"https://www.cakengifts.in/product-images/CGC1126-round-pineapple-cake-n-cherry/regular/round-pineapple-cake-n-cherry.jpg",name:"Pineapple Flavour",price:799},
{image:"https://cdn.igp.com/f_auto,q_auto,t_pnopt9prodlp/products/p-delicious-chocolate-cake-with-premium-frosting-half-kg--135596-m.jpg",name:"Vanila Flavour",price:750},
{image:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSlsosbtav34bXi3w0Nuqimh-UKGBk-nvOQyQ&usqp=CAU",name:"Chocolate Flavour",price:550},
{image:"https://loskitchenco.com/wp-content/uploads/2020/02/IMG_1159-4.jpg",name:"Ruspberry Flavour",price:550}]

  public totalItem : number = 0

  constructor( private cart : CartService) { }  //inject cart service

  ngOnInit(): void {
    this.cart.getProducts().subscribe(res =>{
      this.totalItem = res.length;  //length the property which we get on response
    })
    this.imageSrc.forEach((a:any) => {
      Object.assign(a,{quantity:1,tprice:a.price});
    });
    
  }
  addtoCart(item : any){     //// item which is coming from .html file it consist of product item 
    console.log(item);
    this.cart.addtoCart(item);
  }

}
