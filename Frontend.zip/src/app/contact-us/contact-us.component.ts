import { NgForm } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-contact-us',
  templateUrl: './contact-us.component.html',
  styleUrls: ['./contact-us.component.css']
})
export class ContactUsComponent implements OnInit {
  public info = [];
  constructor(private auth:AuthService) { }

  ngOnInit(): void {
   
  }


  saveUserInfo(data: NgForm){
    if(data.invalid){
      return;
    }
  
      this.auth.createContactData(data.value.name,data.value.mobileno,data.value.email,data.value.message);
        alert("Thanks for your feedback");
      
    }



}
