import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  baseUrl : any = environment.baseURL;

  constructor(private http: HttpClient) { }



  // getProduct(){
  //   return this.http.get("http://localhost:8081/api2/getImage")
  //   .pipe(map((res:any)=>{
  //     console.log(res)
  //     return res;

  //   }))
  // }



  getUserDetails(){
    //get user data from api server and return
    return this.http.get(this.baseUrl);

  }


  createUser(name: string ,mobileno:string, email: string ,password: string){
    const authData  = {name:name ,mobileNo:mobileno, email:email , password:password};
    this.http.post("http://localhost:8081/api/signup",authData)
      .subscribe(response =>{
        console.log(response);
      });

    }






    createContactData(name: string,mno: number,email:string,message:string){
      const userinfo = {name:name,mobileNo:mno,email:email,msg:message};
      this.http.post("http://localhost:8081/api2/data",userinfo)
      .subscribe(res =>{
        console.log(res);
      });

    }

    createCustmizedData(tofcake: string,wofcake:string,sofcake:string,flavour:string,occassion:string,topper:string){
      const cakeinfo = {tofcake:tofcake,wofcake:wofcake,sofcake:sofcake,flavour:flavour,occassion:occassion,topper:topper}
      this.http.post("http://localhost:8081/api3/pcake",cakeinfo)
      .subscribe(res => {
        console.log(res);
      })
    }


    saveOrderDetails(fname: string,lname:string,mno:number,email:string,address:string){
      const details = {fname:fname,lname:lname,mobileNo: mno,email:email,address:address}
      this.http.post("http://localhost:8081/api4/createorder",details)
      .subscribe(response => {
        console.log(response);
      })
    }


    getOrderDetails(){
      return this.http.get("http://localhost:8081/api4/orderinfo");
    }
}
