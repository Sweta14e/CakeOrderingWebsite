import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { AuthService } from '../auth.service';
import { CartService } from '../cart.service';

@Component({
  selector: 'app-customizedcake',
  templateUrl: './customizedcake.component.html',
  styleUrls: ['./customizedcake.component.css']
})
export class CustomizedcakeComponent implements OnInit {

  public totalItem : number = 0;
  constructor(private cart : CartService,private auth : AuthService) { }

  ngOnInit(): void {
    this.cart.getProducts().subscribe(res =>{
      this.totalItem = res.length;  //length the property which we get on response
    })
  }

  formSubmit(form: NgForm){
    if(form.invalid){
      return;
    }
    this.auth.createCustmizedData(form.value.tofcake,form.value.wofcake,form.value.sofcake,form.value.flavour,form.value.occassion,form.value.topper)
    alert("Your response has been submited successfully")
  
  }

}
