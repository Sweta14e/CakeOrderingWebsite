const mongoose = require('mongoose');

const ImageSchema = mongoose.Schema({
    name :{type: String},
    price: {type:Number},
    description:{type:String},
    image:{data:Buffer, contentType: String}
})

module.exports = mongoose.model('imageSchema',ImageSchema)