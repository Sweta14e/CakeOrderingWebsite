const express = require("express");
const router = express.Router();
const bcrypt = require("bcryptjs");
const User = require("../../models/user");
const Contactus =require("../../models/contactus");
const Customizedcake = require("../../models/customizedcake");

module.exports = function (router){
router.post('/signup',function(req,res){
  let note =new User(req.body)
  note.save(function (err,note){
      if (err){
          return res.status(400).json(err)
      }
      res.status(200).json(note)
  })
})
router.get('/users',function(req,res){
   
    User.find({},(err,document)=> {     //{} means find everything 
        //check if error was found or not
        if(err){
            res.json({success:false,message:err});  //return error message
        }
        else{
            //check if data were found in database
            if(!User){
                res.json({success:false,message: 'No user found.'}); //return error 
            }
            else {
                res.json({success:true,users:document}); //return success
            }
        }
    })
})
router.post('/contact',function(req,res){
    let note =new Contactus(req.body)
    note.save(function (err,note){
        if (err){
            return res.status(400).json(err)
        }
        res.status(200).json(note)
    })
  })
  router.get('/contactus',function(req,res){
   
    Contactus.find({},(err,document)=> {     //{} means find everything 
        //check if error was found or not
        if(err){
            res.json({success:false,message:err});  //return error message
        }
        else{
            //check if data were found in database
            if(!Contactus){
                res.json({success:false,message: 'No user found.'}); //return error 
            }
            else {
                res.json({success:true,contactus:document}); //return success
            }
        }
    })
})
  router.post('/customize',function(req,res){
    let note =new Customizedcake(req.body)
    note.save(function (err,note){
        if (err){
            return res.status(400).json(err)
        }
        res.status(200).json(note)
    })
  })
  router.get('/customizedcake',function(req,res){
   
    Customizedcake.find({},(err,document)=> {     //{} means find everything 
        //check if error was found or not
        if(err){
            res.json({success:false,message:err});  //return error message
        }
        else{
            //check if data were found in database
            if(!Customizedcake){
                res.json({success:false,message: 'No user found.'}); //return error 
            }
            else {
                res.json({success:true,customizedcake:document}); //return success
            }
        }
    })
})
}