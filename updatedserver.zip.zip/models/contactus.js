const mongoose = require('mongoose')

const contactusSchema = new mongoose.Schema({
   
    name : {type : String, required: [true, "Username is required!"] },
    mobileno: {type: Number, required: [true, "Phone number is required!"] },
    email : {type: String, required: [true, "Email is required!"]},
    message : {type: String}
   
}, { collection: 'contactus' })

module.exports = mongoose.model('Contactus',contactusSchema)

