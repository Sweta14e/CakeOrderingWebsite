const mongoose = require('mongoose')

const customizedcakeSchema = new mongoose.Schema({
   
    tc : {type : String, required: [true, "Type of cake is required!"] },
    wc: {type: String, required: [true, "Weight of cake is required!"] },
    sc : {type: String, required: [true, "Shape of cake is required!"]},
    f : {type : String, required: [true, "Flovour of cake is required!"] },
    o: {type: String, required: [true, "Occasion of cake is required!"] },
    ct : {type: String, required: [true, "Cake topper is required!"]},
    ui : {type: String}
}, { collection: 'customizedcake' })

module.exports = mongoose.model('Customizedcake',customizedcakeSchema)

