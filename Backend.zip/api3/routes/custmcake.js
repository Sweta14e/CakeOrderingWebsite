const express = require('express')
const custm = require('../../models/custmcake')


module.exports = function(router){

    router.post('/pcake',(req,res)=>{
        let values = new custm(req.body)
        values.save(function(err,values){
            if(err){
               return res.status(400).json(err)
            }
           res.status(200).json(values);
        })
    })


    router.get('/cakedata',(req,res)=>{
        custm.find({},(err,data)=>{
            if(err){
                res.json({success: false,message:err})
            }
            else{
                if(!custm){
                    res.json({success:false,message:'no data found'})
                }
                else{
                    res.json({succes:true,data : data})
                }
            }
        })
    })
}