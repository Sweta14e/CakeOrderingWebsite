
const mongoose = require('mongoose')

const custmcakeSchema = new mongoose.Schema({
    tofcake : {type:String},
    wofcake : {type : String},
    sofcake : {type : String},
    flavour : {type: String},
    occassion : {type: String},
    topper : {type : String},
    comment: {type: String}
})


module.exports = mongoose.model('Custmcake',custmcakeSchema)