const express = require('express')

const order = require('../../models/orderdetail')



module.exports = function(router){

    router.post('/createorder',(req,res)=>{
        let info = new order(req.body)
        info.save(function(err,info){
            if(err){
               return res.status(400).json(err)
            }
           res.status(200).json(info);
        })
    })


    router.get('/orderinfo',(req,res)=>{
        order.find({},(err,data)=>{
            if(err){
                res.json({success: false,message:err})
            }
            else{
                if(!order){
                    res.json({success:false,message:'no data found'})
                }
                else{
                    res.json({succes:true,data : data})
                }
            }
        })
    })
}