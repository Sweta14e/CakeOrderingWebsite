const express = require("express");

const bcrypt = require("bcryptjs");
//const jwt = require("jsonwebtoken");
const User = require("../../models/user");



module.exports = function (router){
router.post("/signup", (req,res, next)=>{
  // bcrypt.hash(req.body.password,10)
  //   .then(hash => {
  //     const user = new User({
  //       name : req.body.name,
       
  //       email : req.body.email,
  //       password : hash,
  //       next
      
  //     });
  //     user.save()
  //       .then(result =>{
  //         res.status(201).json({
  //           message : 'User created!',
  //           result: result
  //         });
  //       })

  //       .catch(err =>{
  //         res.status(500).json({
  //           error :err
  //         });
  //       });
  //     });
  let note = new User(req.body)
  note.save(function (err,note){
      if (err){
          return res.status(400).json(err)
      }
      res.status(200).json(note)
  })

})

router.get('/users',function(req,res){
   
    User.find({},(err,document)=> {     //{} means find everything 
        //check if error was found or not
        if(err){
            res.json({success:false,message:err});  //return error message
        }
        else{
            //check if data were found in database
            if(!User){
                res.json({success:false,message: 'No user found.'}); //return error 
            }
            else {
                res.json({success:true,users:document}); //return success
            }
        }
    })
})
}