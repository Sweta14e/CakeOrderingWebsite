import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from './../auth.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  //private router: Router,
  constructor(public authService : AuthService, private router: Router) { }

  ngOnInit(): void {
  }


  onSignup(form:  NgForm){

    if(form.invalid){
      return;
    }
    console.log(form.value.mobnum)
    this.authService.createUser(form.value.name, form.value.mobnum, form.value.email,form.value.password);

    this.router.navigate(['login']);
  };



  goToLogin(){
    this.router.navigate(['login']);
  }

  
}
